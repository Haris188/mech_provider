
import 'package:flutter/material.dart';

import 'material_app.dart';

void main(List<String> args) {
  runApp(
    Tryst().getMaterialApp()
  );
}